/**
 * System Tray Module for VICAS Device Management
 * Provides system tray icon with menu:
 * - Open Browser
 * - Show/Hide Console
 * - Startup with Windows
 * - Restart Server
 * - Exit
 */

const SysTray = require('systray2').default;
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

class SystemTray {
  constructor(options = {}) {
    this.port = options.port || 3000;
    this.baseDir = options.baseDir || __dirname;
    this.isPackaged = options.isPackaged || false;
    this.onExit = options.onExit || (() => process.exit(0));
    this.onRestart = options.onRestart || (() => {});
    this.getTunnelUrl = options.getTunnelUrl || (() => null);
    
    this.systray = null;
    this.startupEnabled = false;
    this.consoleVisible = true;
    
    // Check startup status
    this.checkStartupStatus();
  }
  
  // Get icon path (works for both dev and packaged)
  getIconPath() {
    if (this.isPackaged) {
      // When packaged, icon should be in data folder
      const dataIconPath = path.join(this.baseDir, 'data', 'vicas.ico');
      if (fs.existsSync(dataIconPath)) {
        return dataIconPath;
      }
      // Fallback to embedded icon
      return path.join(__dirname, 'public', 'images', 'vicas.ico');
    }
    return path.join(__dirname, 'public', 'images', 'vicas.ico');
  }
  
  // Read icon as base64
  getIconBase64() {
    try {
      const iconPath = this.getIconPath();
      if (fs.existsSync(iconPath)) {
        return fs.readFileSync(iconPath).toString('base64');
      }
    } catch (e) {
      console.error('Error reading icon:', e.message);
    }
    // Return empty string if icon not found (systray will use default)
    return '';
  }
  
  // Check if app is set to start with Windows
  checkStartupStatus() {
    try {
      const { execSync } = require('child_process');
      const regQuery = execSync(
        'reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" /v "VICAS Device Management"',
        { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }
      );
      this.startupEnabled = regQuery.includes('VICAS');
    } catch (e) {
      this.startupEnabled = false;
    }
  }
  
  // Toggle startup with Windows
  toggleStartup() {
    const exePath = process.execPath;
    const regKey = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
    
    try {
      if (this.startupEnabled) {
        // Remove from startup
        exec(`reg delete "${regKey}" /v "VICAS Device Management" /f`, (err) => {
          if (!err) {
            this.startupEnabled = false;
            this.updateMenu();
            console.log('✓ Đã tắt khởi động cùng Windows');
          }
        });
      } else {
        // Add to startup
        exec(`reg add "${regKey}" /v "VICAS Device Management" /t REG_SZ /d "${exePath}" /f`, (err) => {
          if (!err) {
            this.startupEnabled = true;
            this.updateMenu();
            console.log('✓ Đã bật khởi động cùng Windows');
          }
        });
      }
    } catch (e) {
      console.error('Error toggling startup:', e.message);
    }
  }
  
  // Open browser to local URL
  openBrowser() {
    const url = `http://localhost:${this.port}`;
    exec(`start "" "${url}"`);
  }
  
  // Open browser to tunnel URL
  openTunnelUrl() {
    const tunnelUrl = this.getTunnelUrl();
    if (tunnelUrl) {
      exec(`start "" "${tunnelUrl}"`);
    } else {
      console.log('⚠️ Tunnel chưa kết nối');
    }
  }
  
  // Show notification
  showNotification(title, message) {
    // Windows notification via PowerShell
    const ps = `
      [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
      $template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
      $textNodes = $template.GetElementsByTagName("text")
      $textNodes.Item(0).AppendChild($template.CreateTextNode("${title}")) | Out-Null
      $textNodes.Item(1).AppendChild($template.CreateTextNode("${message}")) | Out-Null
      $toast = [Windows.UI.Notifications.ToastNotification]::new($template)
      [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("VICAS").Show($toast)
    `;
    exec(`powershell -command "${ps.replace(/\n/g, ' ')}"`, { shell: 'powershell.exe' });
  }
  
  // Create menu configuration
  createMenuConfig() {
    const tunnelUrl = this.getTunnelUrl();
    
    return {
      icon: this.getIconBase64(),
      title: 'VICAS Device Management',
      tooltip: `VICAS - Port ${this.port}`,
      items: [
        {
          title: '🌐 Mở trang web (Local)',
          tooltip: `http://localhost:${this.port}`,
          enabled: true
        },
        {
          title: tunnelUrl ? `🔗 Mở URL công khai` : '🔗 Tunnel chưa kết nối',
          tooltip: tunnelUrl || 'Đang chờ kết nối...',
          enabled: !!tunnelUrl
        },
        SysTray.separator,
        {
          title: this.startupEnabled ? '✓ Khởi động cùng Windows' : '☐ Khởi động cùng Windows',
          tooltip: 'Tự động chạy khi Windows khởi động',
          enabled: true
        },
        SysTray.separator,
        {
          title: '🔄 Khởi động lại',
          tooltip: 'Restart server',
          enabled: true
        },
        {
          title: '🚪 Thoát',
          tooltip: 'Dừng và thoát ứng dụng',
          enabled: true
        }
      ]
    };
  }
  
  // Update menu (recreate with new state)
  updateMenu() {
    if (this.systray) {
      this.systray.kill(false);
    }
    this.start();
  }
  
  // Get systray binary directory
  getBinaryDir() {
    if (this.isPackaged) {
      // When packaged, binary is in the same folder as VICAS.exe
      return this.baseDir;
    }
    // In development, use node_modules path
    return path.join(__dirname, 'node_modules', 'systray2', 'traybin');
  }
  
  // Start system tray
  start() {
    const menuConfig = this.createMenuConfig();
    const binaryDir = this.getBinaryDir();
    
    // Check if binary exists
    const binaryPath = path.join(binaryDir, 'tray_windows_release.exe');
    if (!fs.existsSync(binaryPath)) {
      console.log('⚠️ System tray binary not found:', binaryPath);
      return;
    }
    
    this.systray = new SysTray({
      menu: menuConfig,
      debug: false,
      copyDir: binaryDir
    });
    
    // Attach event listeners
    this.systray.onClick(action => {
      switch (action.seq_id) {
        case 0: // Open Local URL
          this.openBrowser();
          break;
        case 1: // Open Tunnel URL
          this.openTunnelUrl();
          break;
        // 2 is separator
        case 3: // Toggle Startup
          this.toggleStartup();
          break;
        // 4 is separator
        case 5: // Restart
          console.log('🔄 Đang khởi động lại...');
          this.onRestart();
          break;
        case 6: // Exit
          console.log('👋 Đang thoát...');
          this.systray.kill(false);
          this.onExit();
          break;
      }
    });
    
    this.systray.onReady(() => {
      console.log('📌 System tray đã sẵn sàng');
    });
    
    this.systray.onError(err => {
      console.log('⚠️ System tray error:', err.message || err);
    });
  }
  
  // Stop system tray
  stop() {
    if (this.systray) {
      this.systray.kill(false);
      this.systray = null;
    }
  }
  
  // Refresh tunnel URL in menu
  refreshTunnelUrl() {
    // Recreate menu to show updated tunnel URL
    if (this.systray) {
      this.updateMenu();
    }
  }
}

module.exports = SystemTray;
